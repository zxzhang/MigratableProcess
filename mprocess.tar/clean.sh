rm ./src/edu/cmu/courses/ds/launchingProcesses/*.class
rm ./src/edu/cmu/courses/ds/mprocess/*.class
rm ./src/edu/cmu/courses/ds/transactionalFileStream/*.class
