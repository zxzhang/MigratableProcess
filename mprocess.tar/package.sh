tar -cvf mprocess.tar *
