javac -classpath ./src ./src/edu/cmu/courses/ds/launchingProcesses/*.java ./src/edu/cmu/courses/ds/mprocess/*.java ./src/edu/cmu/courses/ds/transactionalFileStream/*.java

java -classpath ./src edu.cmu.courses.ds.launchingProcesses.ProcessManager master
