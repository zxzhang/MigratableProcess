sh package.sh
scp mprocess.tar zhengxiz@linux.andrew.cmu.edu:private/MigratableProcess
